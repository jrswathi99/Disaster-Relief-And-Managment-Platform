package utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidationUtils {
    
    /**
     * Validates if the given email follows a valid email format.
     * @param email The email to be validated.
     * @return true if valid, false otherwise.
     */
    public static boolean isValidEmail(String email) {
        if (email == null || email.isEmpty()) {
            System.out.println("Error: Email cannot be null or empty.");
            return false;
        }
        String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";
        if (!email.matches(emailRegex)) {
            System.out.println("Error: Invalid email format.");
            return false;
        }
        return true;
    }

    /**
     * Validates if the given name contains only alphabets and spaces.
     * @param name The name to be validated.
     * @return true if valid, false otherwise.
     */
    public static boolean isValidName(String name) {
        if (name == null) {
            System.out.println("Error: Name cannot be null.");
            return false;
        }
        if (name.isEmpty()) {
            System.out.println("Error: Name cannot be empty.");
            return false;
        }
        String nameRegex = "^[a-zA-Z\\s]+$";
        if (!name.matches(nameRegex)) {
            System.out.println("Error: Name must contain only alphabets and spaces.");
            return false;
        }
        return true;
    }

    /**
     * Validates if the given age is between 18 and 120.
     * @param age The age to be validated.
     * @return true if valid, false otherwise.
     */
    public static boolean isValidAge(String age) {
        if (age == null || age.isEmpty()) {
            System.out.println("Error: Age cannot be null or empty.");
            return false;
        }
        try {
            int ageInt = Integer.parseInt(age);
            if (ageInt < 18 || ageInt > 120) {
                System.out.println("Error: Age must be between 18 and 120.");
                return false;
            }
        } catch (NumberFormatException e) {
            System.out.println("Error: Age must be a valid whole number.");
            return false;
        }
        return true;
    }

    /**
     * Validates if the given password meets security criteria.
     * Criteria:
     * - At least 8 characters
     * - At least 1 uppercase letter
     * - At least 1 lowercase letter
     * - At least 1 digit
     * - At least 1 special character
     * @param password The password to be validated.
     * @return true if valid, false otherwise.
     */
    public static boolean isValidPassword(String password) {
        if (password == null || password.isEmpty()) {
            System.out.println("Error: Password cannot be null or empty.");
            return false;
        }
        if (password.length() < 8) {
            System.out.println("Error: Password must be at least 8 characters long.");
            return false;
        }
        String passwordRegex = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$";
        if (!password.matches(passwordRegex)) {
            System.out.println("Error: Password must contain at least one uppercase letter, one lowercase letter, one digit, and one special character.");
            return false;
        }
        return true;
    }

    /**
     * Validates if the given quantity is a positive number.
     * @param quantity The quantity to be validated.
     * @return true if valid, false otherwise.
     */
    public static boolean isValidQuantity(int quantity) {
        if (quantity < 0) {
            System.out.println("Error: Quantity cannot be negative.");
            return false;
        }
        return true;
    }
}
